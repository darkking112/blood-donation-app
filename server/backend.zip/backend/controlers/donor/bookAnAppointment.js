const db = require("../dbinstance")

const bookAnAppointment = async function (req, res) {
    const { donorId, DCID } = req.body;
    const query = "INSERT INTO `appointment` (Appointment_Date, Appointment_Time, Appointment_Status, Donor_ID, DC_ID)"
                    + "VALUES (?, ?, ?, ?, ?);";

    let now = new Date();
    now.setDate(now.getDate() + 1);
    const formattedDate = now.toISOString().split('T')[0];
    const formattedTime = now.toTimeString().split(' ')[0];

    const values = [formattedDate, formattedTime, "Pending", donorId, DCID];

    const result = await db.promise().query(query, values);
    const { insertId } = result[0];

    if (insertId)
        return res.json("Appointment Booked Successfully");
    else 
        return res.json("An Error Occurred");
}

module.exports = bookAnAppointment;