const db = require("../dbinstance");

const nurseList = async function (req, res) {
    const query = "SELECT Nurse_ID, Nurse_Name, Nurse_Email FROM `nurse`;";

    db.query(query, (err, result) => {
        if (err)
            return res.json(err);
        if (result.length > 0)
            return res.json(result);
        else
            return res.json("No Records Found");
    })
}

module.exports = nurseList;